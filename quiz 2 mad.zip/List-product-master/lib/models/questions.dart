import 'package:flutter/material.dart';
class question {
  final String question, answer;
  final bool True ;
  Product({
    required this.question,
    required this.answer,
  });
}