import 'package:flutter/material.dart';
import '../models/questions.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  // Create a list of products
  bool _isTrue = false;

  void _toggleTrueFalse() {
    setState(() {
      _isTrue = !_isTrue;
    });
  final List<Question> products = [
    Question1(
      name: 'Do you study mobile application development?',


      description: 'Tasty and healthy! Just don\'t eat it!',
    ),
    Question2(
      name: 'Is mobile application Flutter Based?',


      description: 'Don\'t eat it!',
    )
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('questions'),
        backgroundColor: Colors.blueGrey[200],
      ),
      body: Center(
        child: Text(
          'The value is ${_isTrue ? "True" : "False"}',
          style: TextStyle(fontSize: 24),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _toggleTrueFalse,
        tooltip: 'Toggle True/False',
        child: Text(_isTrue ? 'True' : 'False'),
      ),
    );


      ),
    );
  }
}
