import 'package:flutter/material.dart';
import 'package:assignment_2/screens/home.dart';
void main() {
  runApp(
    const MaterialApp(
      title:'Quiz App',
      home: Home(),
      debugShowCheckedModeBanner: false,
    )
  );
}


